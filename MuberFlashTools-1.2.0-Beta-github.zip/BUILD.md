# 在 arm64（含手机 proot）环境构建

AGP 从 Maven 下载的 aapt2 只有 x86_64 版本，在 arm64 上无法执行；同时 Android 16+
平台的 resources.arsc 新格式旧版 aapt2 也读不了。以下是本机验证过的做法：

1. 安装 x86_64 运行环境（Debian/Ubuntu arm64）：
   ```bash
   dpkg --add-architecture amd64
   apt-get update && apt-get install -y qemu-user-static libc6:amd64 libstdc++6:amd64
   ```
2. 准备 build-tools 37 的 aapt2（x86_64）并用 qemu 包装，路径必须以 `aapt2` 结尾：
   ```bash
   mkdir -p /opt/aapt2bin
   cat > /opt/aapt2bin/aapt2 <<'SH'
   #!/bin/sh
   export LD_LIBRARY_PATH=/path/to/build-tools/37.0.0/lib64:/usr/lib/x86_64-linux-gnu
   exec /usr/bin/qemu-x86_64-static -L /usr/x86_64-linux-gnu /path/to/build-tools/37.0.0/aapt2 "$@"
   SH
   chmod +x /opt/aapt2bin/aapt2
   ```
3. 在 `gradle.properties` 中启用：
   ```
   android.aapt2FromMavenOverride=/opt/aapt2bin/aapt2
   ```
4. 平台 37.2 的 SDK 许可需要接受，否则 AGP 会拒绝构建：
   ```bash
   yes | sdkmanager --channel=3 --licenses
   ```
5. 内存有限时建议关闭守护进程与并行：
   ```
   org.gradle.daemon=false
   org.gradle.parallel=false
   kotlin.compiler.execution.strategy=in-process
   ```

构建命令：

```bash
JAVA_HOME=/usr/lib/jvm/java-21-openjdk-arm64 \
ANDROID_HOME=/path/to/android-sdk \
./gradlew --no-daemon :app:assembleRelease
```
