# Muber Flash Tools

<p align="center">
  <img src="docs/icon.png" width="120" alt="icon">
</p>

<p align="center">
  <b>基于 dd 的 Android 分区镜像刷写工具</b><br>
  Kotlin · Jetpack Compose · Miuix · Material 3
</p>

> ⚠️ 本工具会直接写入块设备，操作不可撤销。请仅在自有设备上使用，刷写前务必备份，
> 并确认镜像与目标分区匹配。因误操作导致的设备故障需自行承担。

当前版本：**1.2.0 Beta**（`versionCode 5`，`minSdk 31` / `targetSdk 36`）

## 功能

- 启动时建立 **常驻 su 会话**，自动识别 KernelSU / Magisk / APatch
- 枚举 `/dev/block/by-name` 与 `/dev/block/mapper`，显示名称、容量、块设备路径
- **分区搜索**：按名称或设备路径实时过滤
- 选择 `.img` → 复制到缓存 → `dd bs=8M` 分块写入，实时进度与速度，可取消
- 可选**刷写前备份**到 `/sdcard/Download/MuberToos`
- 可选**写入后回读校验**（SHA-256 比对）
- 刷写成功后提供**一键重启**（二次点击确认）
- 双 UI 风格：**Miuix**（KernelSU-Style-UI-Kit）与 **Material 3**，运行时可切换
- 主题：跟随系统 / 浅色 / 深色，6 个主题色；浮动胶囊底栏可开关
- 设置项持久化到 SharedPreferences

## 环境要求

| 项目 | 版本 |
| --- | --- |
| JDK | 21 |
| Gradle | 9.7.1（仓库自带 `gradlew`） |
| Android Gradle Plugin | 9.4.1 |
| Kotlin / Compose 编译器 | 2.4.20 |
| compileSdk | **37.2** |
| buildTools | 37.0.0 |

Compose / Material3 依赖要求 `compileSdk ≥ 37`，需要安装 Channel 3 的 SDK 平台：

```bash
sdkmanager --channel=3 "platforms;android-37.2" "build-tools;37.0.0" "platform-tools"
```

## 构建

```bash
# Android Studio 打开时自动生成 local.properties；命令行构建需要：
echo "sdk.dir=/path/to/Android/sdk" > local.properties

./gradlew :app:assembleDebug     # app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:assembleRelease   # 未签名（需自行配置 signingConfig）
```

在 arm64 Linux / 手机 proot 内构建需要额外的 aapt2 处理，见 [BUILD.md](BUILD.md)。

## 目录结构

```
app/src/main/java/com/muber/flashtools/
├── MainActivity.kt     入口、状态、文件选择
├── Settings.kt         设置项与持久化
├── Theme.kt            Miuix / Material 主题切换
├── MiuixScreens.kt     Miuix 风格页面
├── MaterialScreens.kt  Material 3 风格页面
├── Shell.kt            su 会话、分区枚举、dd 脚本协议
├── FlashLogic.kt       镜像复制、备份、刷写、校验、重启
└── State.kt            运行时状态
```

## 签名与分发

仓库不包含发布用 keystore。构建 release 后可自行签名：

```bash
apksigner sign --ks your.jks --out app-release-signed.apk app-release-unsigned.apk
```

覆盖安装到已发布版本时，必须使用**相同签名**。

## License

[MIT](LICENSE) · 界面风格来自 KernelSU-Style-UI-Kit（Apache-2.0）与 Miuix 组件库
