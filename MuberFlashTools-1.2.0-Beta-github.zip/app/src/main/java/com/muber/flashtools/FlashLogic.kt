package com.muber.flashtools

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

const val BACKUP_DIR = "/sdcard/Download/MuberToos"

/** 检测 root 与 root 管理器（KernelSU / Magisk / APatch）。 */
suspend fun refreshRoot(state: AppState) = withContext(Dispatchers.IO) {
    if (!RootShell.open()) {
        state.rootChecked = true
        state.rootOk = false
        state.manager = "未找到 su"
        return@withContext
    }
    val r = RootShell.exec("id", 30_000)
    val ok = r.output.contains("uid=0")
    state.rootChecked = true
    state.rootOk = ok
    state.manager = if (ok) {
        val m = RootShell.exec(
            "if [ -d /data/adb/ksu ]; then echo KernelSU; " +
                "elif [ -d /data/adb/magisk ]; then echo Magisk; " +
                "elif [ -d /data/adb/ap ]; then echo APatch; " +
                "else echo su; fi",
            8000,
        )
        m.output.trim().lineSequence().firstOrNull { it.isNotBlank() } ?: "su"
    } else {
        if (r.timeout) "授权超时，点此重试" else "未获取授权"
    }
}

suspend fun readImageMeta(context: Context, uri: Uri): Pair<String, Long> =
    withContext(Dispatchers.IO) {
        var name = "image.img"
        var size = 0L
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni) ?: name
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) {
        }
        name to size
    }

private suspend fun copyImage(context: Context, state: AppState, handle: JobHandle): File =
    withContext(Dispatchers.IO) {
        val uri = state.imageUri ?: throw IllegalStateException("请先选择镜像文件")
        val dir = File(context.cacheDir, "flash").apply { mkdirs() }
        val safe = (state.imageName ?: "image.img")
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .ifEmpty { "image.img" }
        val out = File(dir, safe)
        if (out.exists() && state.imageSize > 0 && out.length() == state.imageSize) return@withContext out
        if (out.exists()) out.delete()

        val expected = state.imageSize
        if (expected > 0) {
            val usable = context.cacheDir.usableSpace
            if (usable in 1 until expected + 32L * 1024 * 1024) {
                throw IllegalStateException("缓存空间不足：需要 ${fmtSize(expected)}，可用 ${fmtSize(usable)}")
            }
        }

        var done = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(out).use { os ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    if (handle.cancelled) throw IllegalStateException("已取消")
                    val n = input.read(buf)
                    if (n <= 0) break
                    os.write(buf, 0, n)
                    done += n
                    val total = if (expected > 0) expected else done
                    state.progress = (done.toFloat() / total).coerceIn(0f, 1f)
                    state.detail = "${fmtSize(done)} / ${fmtSize(total)}"
                }
                os.flush()
            }
        } ?: throw IllegalStateException("无法读取所选文件")

        if (expected > 0 && done != expected) {
            throw IllegalStateException("读取不完整：得到 ${fmtSize(done)}，应为 ${fmtSize(expected)}")
        }
        if (done <= 0L) throw IllegalStateException("镜像内容为空")
        if (state.imageSize <= 0) state.imageSize = done
        out
    }

private fun sha256(file: File): String {
    val md = MessageDigest.getInstance("SHA-256")
    FileInputStream(file).use { input ->
        val buf = ByteArray(1 shl 20)
        while (true) {
            val n = input.read(buf)
            if (n <= 0) break
            md.update(buf, 0, n)
        }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}

/** 完整刷写流程：复制镜像 → 可选备份 → dd 写入 → 可选回读校验。 */
suspend fun startFlash(context: Context, state: AppState) {
    val target = state.target ?: return
    val handle = JobHandle()
    state.handle = handle
    state.busy = true
    state.ok = false
    state.message = null
    state.progress = 0f
    state.stage = "准备镜像"
    state.detail = ""
    state.log("==== 开始刷写 ${target.name} ====")

    try {
        val local = copyImage(context, state, handle)
        val size = if (state.imageSize > 0) state.imageSize else local.length()
        state.log("镜像已就绪：${local.absolutePath}（${fmtSize(size)}）")

        if (state.optBackup) {
            state.stage = "备份 ${target.name}"
            state.progress = 0f
            val out = "$BACKUP_DIR/${target.name}_${stamp()}.img"
            val bo = runScript(
                Scripts.backup(target.dev, out, target.size),
                handle,
                onLog = { state.log(it) },
                onProgress = { p ->
                    state.progress = if (target.size > 0) (p.toFloat() / target.size).coerceIn(0f, 1f) else 0f
                    state.detail = "${fmtSize(p)} / ${fmtSize(target.size)}"
                },
            )
            if (!bo.ok) {
                state.log("备份失败：${bo.message}（继续刷写）")
            } else {
                state.log("备份完成：$out")
            }
        }

        state.stage = "写入 ${target.name}"
        state.progress = 0f
        state.detail = ""
        val fo = runScript(
            Scripts.flash(local.absolutePath, target.dev, size),
            handle,
            onLog = { state.log(it) },
            onProgress = { p ->
                state.progress = if (size > 0) (p.toFloat() / size).coerceIn(0f, 1f) else 0f
                state.detail = "${fmtSize(p)} / ${fmtSize(size)}"
            },
        )
        if (!fo.ok) throw IllegalStateException(fo.message)

        if (state.optVerify) {
            state.stage = "回读校验"
            state.progress = 0f
            val imgHash = withContext(Dispatchers.IO) { sha256(local) }
            state.log("镜像 SHA-256：$imgHash")
            val ro = runScript(Scripts.readback(target.dev, size), handle, onLog = { state.log(it) })
            if (!ro.ok) throw IllegalStateException(ro.message)
            if (!imgHash.equals(ro.meta, ignoreCase = true)) {
                throw IllegalStateException("校验失败：设备内容与镜像不一致")
            }
            state.log("校验通过：设备内容与镜像一致")
        }

        state.stage = "完成"
        state.progress = 1f
        state.ok = true
        state.message = "刷写完成，已写入 ${target.name}，建议重启设备。"
        state.log(state.message!!)
    } catch (e: Exception) {
        state.ok = false
        state.message = e.message ?: e.toString()
        state.log("失败：${state.message}")
    } finally {
        state.busy = false
        state.handle = null
    }
}

/** 单独备份某个分区。 */
suspend fun backupPartition(state: AppState, p: Partition) {
    val handle = JobHandle()
    state.handle = handle
    state.busy = true
    state.ok = false
    state.message = null
    state.stage = "备份 ${p.name}"
    state.progress = 0f
    val out = "$BACKUP_DIR/${p.name}_${stamp()}.img"
    state.log("==== 备份 ${p.name} → $out ====")
    try {
        val ro = runScript(
            Scripts.backup(p.dev, out, p.size),
            handle,
            onLog = { state.log(it) },
            onProgress = { n ->
                state.progress = if (p.size > 0) (n.toFloat() / p.size).coerceIn(0f, 1f) else 0f
                state.detail = "${fmtSize(n)} / ${fmtSize(p.size)}"
            },
        )
        if (!ro.ok) throw IllegalStateException(ro.message)
        state.ok = true
        state.message = "备份完成：$out"
        state.log(state.message!!)
    } catch (e: Exception) {
        state.ok = false
        state.message = e.message ?: "备份失败"
        state.log("失败：${state.message}")
    } finally {
        state.busy = false
        state.handle = null
    }
}


/** 刷写完成后重启设备，交给 su 执行。 */
suspend fun rebootDevice(): String = withContext(Dispatchers.IO) {
    try {
        ProcessBuilder("su", "-c", "sleep 1; reboot").start()
        "正在重启设备…"
    } catch (e: Exception) {
        "重启失败：${e.message}"
    }
}
