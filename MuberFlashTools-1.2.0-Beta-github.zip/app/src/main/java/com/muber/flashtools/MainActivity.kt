package com.muber.flashtools

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

class AppActions(
    val pickImage: () -> Unit,
    val startFlash: () -> Unit,
    val cancelFlash: () -> Unit,
    val reboot: () -> Unit,
    val backupPartition: (Partition) -> Unit,
    val retryRoot: () -> Unit,
    val selectTarget: (Partition) -> Unit,
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = Settings.load(this)

        setContent {
            MuberTheme(settings) {
                val state = remember { AppState() }
                val scope = rememberCoroutineScope()
                val context = LocalContext.current
                var tab by rememberSaveable { mutableIntStateOf(0) }

                val picker = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument()
                ) { uri: Uri? ->
                    if (uri != null) {
                        scope.launch {
                            val meta = readImageMeta(context, uri)
                            state.imageUri = uri
                            state.imageName = meta.first
                            state.imageSize = meta.second
                            state.message = null
                            state.log("已选择镜像：${meta.first}（${fmtSize(meta.second)}）")
                        }
                    }
                }

                val actions = remember {
                    AppActions(
                        pickImage = { picker.launch(arrayOf("*/*")) },
                        startFlash = { scope.launch { startFlash(context, state) } },
                        cancelFlash = { state.handle?.cancel() },
                        reboot = {
                            scope.launch {
                                val msg = rebootDevice()
                                android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        backupPartition = { p -> scope.launch { backupPartition(state, p) } },
                        selectTarget = { p ->
                            state.target = p
                            tab = 1
                        },
                        retryRoot = {
                            scope.launch {
                                refreshRoot(state)
                                try {
                                    state.partitions = Partitions.load()
                                } catch (_: Exception) {
                                }
                            }
                        },
                    )
                }

                LaunchedEffect(Unit) {
                    refreshRoot(state)
                    state.partitionsLoading = true
                    state.log("开始读取分区列表")
                    try {
                        state.partitions = Partitions.load()
                        state.partitionsError = null
                        state.log("分区列表已加载：共 ${state.partitions.size} 个块设备")
                    } catch (e: Exception) {
                        state.partitionsError = e.message ?: "读取分区失败"
                        state.log(state.partitionsError!!)
                    } finally {
                        state.partitionsLoading = false
                    }
                }

                if (settings.uiStyle == UiStyle.MIUIX) {
                    MiuixApp(state, settings, tab, onTab = { tab = it }, actions = actions)
                } else {
                    MaterialApp(state, settings, tab, onTab = { tab = it }, actions = actions)
                }
            }
        }
    }
}

internal fun titleForTab(tab: Int): String = when (tab) {
    0 -> "Muber Flash Tools"
    1 -> "刷写"
    2 -> "分区"
    else -> "设置"
}
