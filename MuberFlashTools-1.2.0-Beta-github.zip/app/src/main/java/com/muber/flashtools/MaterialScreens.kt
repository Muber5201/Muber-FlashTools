package com.muber.flashtools

import androidx.compose.foundation.background
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val padding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 116.dp)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialApp(
    state: AppState,
    settings: Settings,
    tab: Int,
    onTab: (Int) -> Unit,
    actions: AppActions,
) {
    val scheme = MaterialTheme.colorScheme

    Scaffold(
        containerColor = scheme.background,
        topBar = {
            TopAppBar(
                title = { Text(titleForTab(tab), fontWeight = FontWeight.SemiBold) },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (tab) {
                0 -> MaterialHome(state, settings, actions, onFlash = { onTab(1) }, onList = { onTab(2) })
                1 -> MaterialFlash(state, actions, onPickTarget = { onTab(2) })
                2 -> MaterialPartitions(state, actions)
                else -> MaterialSettings(settings)
            }
            MaterialBottomBar(settings, tab, onTab, Modifier.align(Alignment.BottomCenter))
        }
    }
}

@Composable
private fun MaterialBottomBar(
    settings: Settings,
    tab: Int,
    onTab: (Int) -> Unit,
    modifier: Modifier,
) {
    val items = listOf(
        "首页" to Icons.Default.Home,
        "刷写" to Icons.Default.PlayArrow,
        "分区" to Icons.Default.List,
        "设置" to Icons.Default.Settings,
    )
    if (!settings.floatingBar) {
        NavigationBar(modifier = modifier.fillMaxWidth()) {
            items.forEachIndexed { index, item ->
                NavigationBarItem(
                    selected = tab == index,
                    onClick = { onTab(index) },
                    icon = { Icon(item.second, contentDescription = item.first) },
                    label = { Text(item.first) },
                )
            }
        }
    } else {
        val shape = RoundedCornerShape(50)
        Box(
            modifier = modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Surface(
                shape = shape,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shadowElevation = 6.dp,
                tonalElevation = 0.dp,
            ) {
                Row(
                    modifier = Modifier
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    items.forEachIndexed { index, item ->
                        val selected = tab == index
                        Column(
                            modifier = Modifier
                                .clip(shape)
                                .clickable { onTab(index) }
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                                    else Color.Transparent
                                )
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(
                                imageVector = item.second,
                                contentDescription = item.first,
                                tint = if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(22.dp),
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = item.first,
                                fontSize = 10.sp,
                                color = if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MaterialHome(state: AppState, settings: Settings, actions: AppActions, onFlash: () -> Unit, onList: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = padding,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { MaterialRootCard(state, settings, actions.retryRoot) }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    MaterialInfoLine("设备型号", android.os.Build.MODEL ?: "未知")
                    Spacer(Modifier.height(14.dp))
                    MaterialInfoLine(
                        "Android 版本",
                        "Android ${android.os.Build.VERSION.RELEASE}（API ${android.os.Build.VERSION.SDK_INT}）",
                    )
                    Spacer(Modifier.height(14.dp))
                    MaterialInfoLine("处理器架构", android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "未知")
                    Spacer(Modifier.height(14.dp))
                    MaterialInfoLine("Root 实现", state.manager)
                    Spacer(Modifier.height(14.dp))
                    MaterialInfoLine(
                        "分区数量",
                        if (state.partitionsLoading) "读取中…" else "${state.partitions.size} 个",
                    )
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                MaterialRow("选择镜像并刷写", "读取 .img 文件，用 dd 写入目标分区", onFlash)
                HorizontalDivider()
                MaterialRow("浏览分区", "共 ${state.partitions.size} 个块设备", onList)
            }
        }
    }
}

@Composable
private fun MaterialRootCard(state: AppState, settings: Settings, onRetry: () -> Unit) {
    val ok = state.rootOk
    val container = when {
        !state.rootChecked -> Color(0xFFFFF0DB)
        ok -> Color(0xFFDFFAE4)
        else -> Color(0xFFF8E2E2)
    }
    val tint = when {
        !state.rootChecked -> Color(0xFFF5A623)
        ok -> Color(0xFF36D167)
        else -> Color(0xFFF72727)
    }
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = when {
                            !state.rootChecked -> "正在检测 Root 权限"
                            ok -> "超级用户权限已就绪"
                            else -> settings.rootMissingTitle
                        },
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF111111),
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(text = state.manager, fontSize = 14.sp, color = Color(0xFF444444))
                }
                Icon(
                    imageVector = if (ok) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = tint,
                )
            }
            if (state.rootChecked && !ok) {
                TextButton(onClick = onRetry, modifier = Modifier.padding(top = 8.dp)) {
                    Text("重新申请权限")
                }
            }
        }
    }
}

@Composable
private fun MaterialInfoLine(title: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(
            Icons.Default.Info,
            contentDescription = null,
            modifier = Modifier.size(22.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MaterialRow(title: String, summary: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(2.dp))
            Text(summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(
            Icons.Default.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun MaterialSwitchRow(
    title: String,
    summary: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(2.dp))
            Text(summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary),
        )
    }
}

@Composable
private fun MaterialFlash(state: AppState, actions: AppActions, onPickTarget: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    var rebootArmed by remember { mutableStateOf(false) }
    LaunchedEffect(rebootArmed) {
        if (rebootArmed) {
            delay(4000)
            rebootArmed = false
        }
    }
    val canStart = state.rootOk && state.imageUri != null && state.target != null && !state.busy

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = padding,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                MaterialRow(
                    "镜像文件",
                    state.imageName?.let { "$it · ${fmtSize(state.imageSize)}" } ?: "未选择 · 点击选择 .img",
                    actions.pickImage,
                )
                HorizontalDivider()
                MaterialRow(
                    "目标分区",
                    state.target?.let { "${it.name} · ${fmtSize(it.size)}" } ?: "未选择 · 点击从分区列表选择",
                    onPickTarget,
                )
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                MaterialSwitchRow("刷写前备份原分区", "读取当前分区到 Download/MuberToos", state.optBackup) {
                    state.optBackup = it
                }
                HorizontalDivider()
                MaterialSwitchRow("写入后回读校验", "比对设备内容与镜像的 SHA-256", state.optVerify) {
                    state.optVerify = it
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("将要执行", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "dd if=${state.imageName ?: "<镜像>"}\n" +
                            "   of=${state.target?.dev ?: "<块设备>"}\n" +
                            "   bs=8M conv=notrunc\nsync",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                    )
                }
            }
        }
        item {
            Button(
                onClick = { confirm = true },
                modifier = Modifier.fillMaxWidth(),
                enabled = canStart,
            ) {
                Text(if (!state.rootOk) "需要 Root 权限" else "开始刷写")
            }
        }
        if (confirm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0DB)),
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("确认刷写？", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF111111))
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${state.imageName} → ${state.target?.name}\n刷错分区可能导致无法开机，操作不可撤销。",
                            fontSize = 13.sp,
                            color = Color(0xFF7A5320),
                        )
                        Row(Modifier.padding(top = 8.dp)) {
                            TextButton(onClick = { confirm = false }) { Text("取消") }
                            TextButton(onClick = {
                                confirm = false
                                if (canStart) actions.startFlash()
                            }) { Text("立即刷写") }
                        }
                    }
                }
            }
        }
        if (state.busy || state.message != null) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                state.stage.ifEmpty { "准备中" },
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f),
                            )
                            Text("${(state.progress * 100).toInt()}%", style = MaterialTheme.typography.titleLarge)
                        }
                        LinearProgressIndicator(
                            progress = { state.progress },
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        )
                        if (state.detail.isNotEmpty()) {
                            Text(
                                state.detail,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                        state.message?.let { msg ->
                            Text(
                                msg,
                                fontSize = 14.sp,
                                color = if (state.ok) Color(0xFF1FB955) else Color(0xFFE5484D),
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                        Row(Modifier.padding(top = 8.dp)) {
                            if (state.busy) {
                                TextButton(onClick = actions.cancelFlash) { Text("取消任务") }
                            } else if (state.ok) {
                                TextButton(onClick = {
                                    if (rebootArmed) {
                                        rebootArmed = false
                                        actions.reboot()
                                    } else {
                                        rebootArmed = true
                                    }
                                }) { Text(if (rebootArmed) "确认重启" else "重启设备") }
                            }
                        }
                    }
                }
            }
        }
        if (state.logs.isNotEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("执行日志", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(6.dp))
                        state.logs.takeLast(8).forEach { line ->
                            Text(line, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MaterialPartitions(state: AppState, actions: AppActions) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(state.partitions, query) {
        val q = query.trim()
        if (q.isEmpty()) {
            state.partitions
        } else {
            state.partitions.filter {
                it.name.contains(q, ignoreCase = true) || it.dev.contains(q, ignoreCase = true)
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = padding,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    MaterialSearchField(query) { query = it }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = if (query.isBlank()) {
                            "共 ${state.partitions.size} 个块设备"
                        } else {
                            "匹配 ${filtered.size} / ${state.partitions.size} 个块设备"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp),
                    )
                }
            }
        }
        when {
            state.partitionsLoading -> item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text("正在读取块设备…", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }

            state.partitions.isEmpty() -> item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        state.partitionsError ?: "暂无分区数据（需要 Root 权限）",
                        Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }

            filtered.isEmpty() -> item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text("没有匹配的分区", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }

            else -> items(filtered, key = { it.dev }) { p ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    MaterialRow(p.name, "${fmtSize(p.size)} · ${p.dev}") { actions.selectTarget(p) }
                    HorizontalDivider()
                    TextButton(
                        onClick = { actions.backupPartition(p) },
                        modifier = Modifier.padding(start = 16.dp, bottom = 4.dp),
                    ) { Text("备份此分区") }
                }
            }
        }
    }
}

@Composable
private fun MaterialSettings(settings: Settings) {
    val context = LocalContext.current
    var rootTitle by remember(settings.rootMissingTitle) { mutableStateOf(settings.rootMissingTitle) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = padding,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { MaterialSectionHeader("外观") }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(
                        "界面风格",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MaterialChip("Miuix", settings.uiStyle == UiStyle.MIUIX) {
                            settings.updateUiStyle(UiStyle.MIUIX)
                        }
                        MaterialChip("Material", settings.uiStyle == UiStyle.MATERIAL) {
                            settings.updateUiStyle(UiStyle.MATERIAL)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "主题模式",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MaterialChip("跟随系统", settings.themeMode == ThemeMode.SYSTEM) {
                            settings.updateThemeMode(ThemeMode.SYSTEM)
                        }
                        MaterialChip("浅色", settings.themeMode == ThemeMode.LIGHT) {
                            settings.updateThemeMode(ThemeMode.LIGHT)
                        }
                        MaterialChip("深色", settings.themeMode == ThemeMode.DARK) {
                            settings.updateThemeMode(ThemeMode.DARK)
                        }
                    }
                }
            }
        }

        item { MaterialSectionHeader("主题色") }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        KEY_COLORS.forEach { value ->
                            val selected = value == settings.keyColor
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(value))
                                    .then(
                                        if (selected) {
                                            Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                        } else {
                                            Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                                        }
                                    )
                                    .clickable { settings.updateKeyColor(value) }
                            )
                        }
                    }
                }
            }
        }

        item { MaterialSectionHeader("导航栏") }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                MaterialSwitchRow("浮动胶囊底栏", "导航栏变为悬浮胶囊样式", settings.floatingBar) {
                    settings.updateFloatingBar(it)
                }
            }
        }

        item { MaterialSectionHeader("主页文案") }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(
                        "未授权时的标题（默认：未获取超级用户权限）",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    MaterialTextField(rootTitle) { rootTitle = it }
                    Row(Modifier.padding(top = 10.dp)) {
                        TextButton(onClick = {
                            settings.updateRootMissingTitle(rootTitle)
                            android.widget.Toast.makeText(context, "已保存", android.widget.Toast.LENGTH_SHORT).show()
                        }) { Text("保存") }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = {
                            settings.resetHomeTexts()
                            rootTitle = Settings.DEFAULT_ROOT_MISSING
                        }) { Text("恢复默认") }
                    }
                }
            }
        }

        item { MaterialSectionHeader("关于") }
        item { MaterialAboutCard() }
    }
}

@Composable
private fun MaterialTextField(value: String, onChange: (String) -> Unit) {
    BasicTextField(
        value = value,
        onValueChange = onChange,
        textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp),
        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 58.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp),
    )
}

@Composable
private fun MaterialAboutCard() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Muber Flash Tools",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "1.2.0 Beta",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            MaterialAboutLine("作者", "Muber")
            MaterialAboutLine("AI 辅助", "DeepSeek Harness")
            MaterialAboutLine("界面框架", "KernelSU-Style-UI-Kit（Miuix）")
            MaterialAboutLine("包名", "com.muber.flashtools")
            Spacer(Modifier.height(6.dp))
            Text(
                "仅用于自有设备的维护与调试，刷写前请自行备份并确认镜像与分区匹配。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MaterialAboutLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(76.dp),
        )
        Text(text = value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun MaterialSearchField(value: String, onValueChange: (String) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        if (value.isEmpty()) {
            Text(
                text = "搜索分区名称或设备路径",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun MaterialSectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 10.dp, top = 4.dp),
    )
}

@Composable
private fun MaterialChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
    Text(
        text = text,
        color = fg,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}
