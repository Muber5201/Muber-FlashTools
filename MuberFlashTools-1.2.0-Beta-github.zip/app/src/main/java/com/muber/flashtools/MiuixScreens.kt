package com.muber.flashtools

import androidx.compose.foundation.background
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import top.yukonga.miuix.kmp.basic.Button
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.LinearProgressIndicator
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme.colorScheme

private val pagePadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 116.dp)

@Composable
fun MiuixApp(
    state: AppState,
    settings: Settings,
    tab: Int,
    onTab: (Int) -> Unit,
    actions: AppActions,
) {
    val scrollBehavior = MiuixScrollBehavior()

    Scaffold(
        topBar = {
            TopAppBar(
                title = titleForTab(tab),
                scrollBehavior = scrollBehavior,
            )
        },
        popupHost = { },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (tab) {
                0 -> MiuixHome(state, settings, actions, onFlash = { onTab(1) }, onList = { onTab(2) })
                1 -> MiuixFlash(state, actions, onPickTarget = { onTab(2) })
                2 -> MiuixPartitions(state, actions)
                else -> MiuixSettings(settings)
            }
            MiuixBottomBar(
                settings = settings,
                tab = tab,
                onTab = onTab,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

@Composable
private fun MiuixBottomBar(
    settings: Settings,
    tab: Int,
    onTab: (Int) -> Unit,
    modifier: Modifier,
) {
    val items = listOf(
        "首页" to Icons.Default.Home,
        "刷写" to Icons.Default.PlayArrow,
        "分区" to Icons.Default.List,
        "设置" to Icons.Default.Settings,
    )
    if (!settings.floatingBar) {
        NavigationBar(modifier = modifier.fillMaxWidth(), color = colorScheme.surface) {
            items.forEachIndexed { index, item ->
                NavigationBarItem(
                    selected = tab == index,
                    onClick = { onTab(index) },
                    icon = item.second,
                    label = item.first,
                )
            }
        }
    } else {
        val shape = RoundedCornerShape(50)
        Box(
            modifier = modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Row(
                modifier = Modifier
                    .clip(shape)
                    .background(colorScheme.surfaceContainer)
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                items.forEachIndexed { index, item ->
                    val selected = tab == index
                    Column(
                        modifier = Modifier
                            .clip(shape)
                            .clickable { onTab(index) }
                            .background(if (selected) colorScheme.primary.copy(alpha = 0.14f) else Color.Transparent)
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(
                            imageVector = item.second,
                            contentDescription = item.first,
                            tint = if (selected) colorScheme.primary else colorScheme.onSurfaceVariantSummary,
                            modifier = Modifier.size(22.dp),
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = item.first,
                            fontSize = 10.sp,
                            color = if (selected) colorScheme.primary else colorScheme.onSurfaceVariantSummary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiuixHome(
    state: AppState,
    settings: Settings,
    actions: AppActions,
    onFlash: () -> Unit,
    onList: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = pagePadding,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { RootStatusCard(state, settings, actions.retryRoot) }
        item { DeviceInfoCard(state) }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                ArrowPreference(
                    title = "选择镜像并刷写",
                    summary = "读取 .img 文件，用 dd 写入目标分区",
                    startAction = {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 8.dp).size(24.dp),
                            tint = colorScheme.onBackground,
                        )
                    },
                    onClick = onFlash,
                )
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                ArrowPreference(
                    title = "浏览分区",
                    summary = if (state.partitionsLoading) "正在读取…"
                    else "共 ${state.partitions.size} 个块设备",
                    startAction = {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 8.dp).size(24.dp),
                            tint = colorScheme.onBackground,
                        )
                    },
                    onClick = onList,
                )
            }
        }
    }
}

@Composable
private fun RootStatusCard(state: AppState, settings: Settings, onRetry: () -> Unit) {
    val ok = state.rootOk
    val container = when {
        !state.rootChecked -> Color(0xFFFFF0DB)
        ok -> Color(0xFFDFFAE4)
        else -> Color(0xFFF8E2E2)
    }
    val tint = when {
        !state.rootChecked -> Color(0xFFF5A623)
        ok -> Color(0xFF36D167)
        else -> Color(0xFFF72727)
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.defaultColors(color = container),
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = when {
                            !state.rootChecked -> "正在检测 Root 权限"
                            ok -> "超级用户权限已就绪"
                            else -> settings.rootMissingTitle
                        },
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF111111),
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = state.manager,
                        fontSize = 14.sp,
                        color = Color(0xFF444444),
                    )
                }
                Icon(
                    imageVector = if (ok) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = tint,
                )
            }
            if (state.rootChecked && !ok) {
                TextButton(
                    text = "重新申请权限",
                    onClick = onRetry,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun DeviceInfoCard(state: AppState) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            InfoLine("设备型号", android.os.Build.MODEL ?: "未知")
            Spacer(Modifier.height(14.dp))
            InfoLine(
                "Android 版本",
                "Android ${android.os.Build.VERSION.RELEASE}（API ${android.os.Build.VERSION.SDK_INT}）",
            )
            Spacer(Modifier.height(14.dp))
            InfoLine("处理器架构", android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "未知")
            Spacer(Modifier.height(14.dp))
            InfoLine("Root 实现", state.manager)
            Spacer(Modifier.height(14.dp))
            InfoLine("分区数量", if (state.partitionsLoading) "读取中…" else "${state.partitions.size} 个")
        }
    }
}

@Composable
private fun InfoLine(title: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            modifier = Modifier.size(22.dp),
            tint = colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = colorScheme.onSurface)
            Text(text = value, fontSize = 13.sp, color = colorScheme.onSurfaceVariantSummary)
        }
    }
}

@Composable
private fun AboutCard() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Muber Flash Tools",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colorScheme.onSurface,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "1.2.0 Beta",
                    fontSize = 11.sp,
                    color = colorScheme.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(colorScheme.primary.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            AboutLine("作者", "Muber")
            AboutLine("AI 辅助", "DeepSeek Harness")
            AboutLine("界面框架", "KernelSU-Style-UI-Kit（Miuix）")
            AboutLine("包名", "com.muber.flashtools")
            Spacer(Modifier.height(6.dp))
            Text(
                text = "仅用于自有设备的维护与调试，刷写前请自行备份并确认镜像与分区匹配。",
                fontSize = 12.sp,
                color = colorScheme.onSurfaceVariantSummary,
            )
        }
    }
}

@Composable
private fun AboutLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = colorScheme.onSurfaceVariantSummary,
            modifier = Modifier.width(76.dp),
        )
        Text(text = value, fontSize = 13.sp, color = colorScheme.onSurface)
    }
}

@Composable
private fun MiuixFlash(state: AppState, actions: AppActions, onPickTarget: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    var rebootArmed by remember { mutableStateOf(false) }
    LaunchedEffect(rebootArmed) {
        if (rebootArmed) {
            delay(4000)
            rebootArmed = false
        }
    }
    val canStart = state.rootOk && state.imageUri != null && state.target != null && !state.busy

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = pagePadding,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                ArrowPreference(
                    title = "镜像文件",
                    summary = state.imageName?.let { "$it · ${fmtSize(state.imageSize)}" }
                        ?: "未选择 · 点击选择 .img",
                    startAction = {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 8.dp).size(24.dp),
                            tint = colorScheme.onBackground,
                        )
                    },
                    onClick = actions.pickImage,
                )
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                ArrowPreference(
                    title = "目标分区",
                    summary = state.target?.let { "${it.name} · ${fmtSize(it.size)}" }
                        ?: "未选择 · 点击从分区列表选择",
                    startAction = {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 8.dp).size(24.dp),
                            tint = colorScheme.onBackground,
                        )
                    },
                    onClick = onPickTarget,
                )
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                SwitchPreference(
                    title = "刷写前备份原分区",
                    summary = "读取当前分区到 Download/MuberToos",
                    checked = state.optBackup,
                    onCheckedChange = { state.optBackup = it },
                )
                SwitchPreference(
                    title = "写入后回读校验",
                    summary = "比对设备内容与镜像的 SHA-256，速度较慢",
                    checked = state.optVerify,
                    onCheckedChange = { state.optVerify = it },
                )
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(text = "将要执行", fontSize = 13.sp, color = colorScheme.onSurfaceVariantSummary)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "dd if=${state.imageName ?: "<镜像>"}\n" +
                            "   of=${state.target?.dev ?: "<块设备>"}\n" +
                            "   bs=8M conv=notrunc\nsync",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = colorScheme.onSurface,
                    )
                }
            }
        }
        item {
            Button(
                onClick = { confirm = true },
                modifier = Modifier.fillMaxWidth(),
                enabled = canStart,
            ) {
                Text(text = if (!state.rootOk) "需要 Root 权限" else "开始刷写", color = Color.White)
            }
        }

        if (confirm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.defaultColors(color = Color(0xFFFFF0DB)),
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(
                            text = "确认刷写？",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF111111),
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "${state.imageName} → ${state.target?.name}\n刷错分区可能导致无法开机，操作不可撤销。",
                            fontSize = 13.sp,
                            color = Color(0xFF7A5320),
                        )
                        Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                            TextButton(text = "取消", onClick = { confirm = false })
                            Spacer(Modifier.width(8.dp))
                            TextButton(
                                text = "立即刷写",
                                onClick = {
                                    confirm = false
                                    if (canStart) actions.startFlash()
                                },
                            )
                        }
                    }
                }
            }
        }

        if (state.busy || state.message != null) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = state.stage.ifEmpty { "准备中" },
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = colorScheme.onSurface,
                                modifier = Modifier.weight(1f),
                            )
                            Text(
                                text = "${(state.progress * 100).toInt()}%",
                                fontSize = 20.sp,
                                color = colorScheme.onSurface,
                            )
                        }
                        LinearProgressIndicator(
                            progress = state.progress,
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        )
                        if (state.detail.isNotEmpty()) {
                            Text(
                                text = state.detail,
                                fontSize = 13.sp,
                                color = colorScheme.onSurfaceVariantSummary,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                        state.message?.let { msg ->
                            Text(
                                text = msg,
                                fontSize = 14.sp,
                                color = if (state.ok) Color(0xFF1FB955) else Color(0xFFE5484D),
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                        Row(modifier = Modifier.padding(top = 8.dp)) {
                            if (state.busy) {
                                TextButton(text = "取消任务", onClick = actions.cancelFlash)
                            } else if (state.ok) {
                                TextButton(
                                    text = if (rebootArmed) "确认重启" else "重启设备",
                                    onClick = {
                                        if (rebootArmed) {
                                            rebootArmed = false
                                            actions.reboot()
                                        } else {
                                            rebootArmed = true
                                        }
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }

        if (state.logs.isNotEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(text = "执行日志", fontSize = 13.sp, color = colorScheme.onSurfaceVariantSummary)
                        Spacer(Modifier.height(6.dp))
                        state.logs.takeLast(8).forEach { line ->
                            Text(
                                text = line,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiuixPartitions(state: AppState, actions: AppActions) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(state.partitions, query) {
        val q = query.trim()
        if (q.isEmpty()) {
            state.partitions
        } else {
            state.partitions.filter {
                it.name.contains(q, ignoreCase = true) || it.dev.contains(q, ignoreCase = true)
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = pagePadding,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                    MiuixSearchField(query) { query = it }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = if (query.isBlank()) {
                            "共 ${state.partitions.size} 个块设备"
                        } else {
                            "匹配 ${filtered.size} / ${state.partitions.size} 个块设备"
                        },
                        fontSize = 12.sp,
                        color = colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.padding(start = 4.dp),
                    )
                }
            }
        }
        when {
            state.partitionsLoading -> item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "正在读取块设备…",
                        modifier = Modifier.padding(16.dp),
                        fontSize = 14.sp,
                        color = colorScheme.onSurfaceVariantSummary,
                    )
                }
            }

            state.partitions.isEmpty() -> item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = state.partitionsError ?: "暂无分区数据（需要 Root 权限）",
                        modifier = Modifier.padding(16.dp),
                        fontSize = 14.sp,
                        color = colorScheme.onSurfaceVariantSummary,
                    )
                }
            }

            filtered.isEmpty() -> item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "没有匹配的分区",
                        modifier = Modifier.padding(16.dp),
                        fontSize = 14.sp,
                        color = colorScheme.onSurfaceVariantSummary,
                    )
                }
            }

            else -> items(filtered, key = { it.dev }) { p ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        ArrowPreference(
                            title = p.name,
                            summary = "${fmtSize(p.size)} · ${p.dev}",
                            onClick = { actions.selectTarget(p) },
                        )
                        TextButton(
                            text = "备份此分区",
                            onClick = { actions.backupPartition(p) },
                            modifier = Modifier.padding(start = 16.dp, bottom = 4.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiuixSettings(settings: Settings) {
    val context = LocalContext.current
    var rootTitle by remember(settings.rootMissingTitle) { mutableStateOf(settings.rootMissingTitle) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = pagePadding,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { MiuixSectionHeader("外观") }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    SettingsTitle("界面风格")
                    Spacer(Modifier.height(8.dp))
                    MiuixChoiceRow(
                        options = listOf(
                            "Miuix" to (settings.uiStyle == UiStyle.MIUIX),
                            "Material" to (settings.uiStyle == UiStyle.MATERIAL),
                        ),
                    ) { index ->
                        settings.updateUiStyle(if (index == 0) UiStyle.MIUIX else UiStyle.MATERIAL)
                    }
                    Spacer(Modifier.height(18.dp))
                    SettingsTitle("主题模式")
                    Spacer(Modifier.height(8.dp))
                    MiuixChoiceRow(
                        options = listOf(
                            "跟随系统" to (settings.themeMode == ThemeMode.SYSTEM),
                            "浅色" to (settings.themeMode == ThemeMode.LIGHT),
                            "深色" to (settings.themeMode == ThemeMode.DARK),
                        ),
                    ) { index ->
                        settings.updateThemeMode(
                            when (index) {
                                1 -> ThemeMode.LIGHT
                                2 -> ThemeMode.DARK
                                else -> ThemeMode.SYSTEM
                            },
                        )
                    }
                }
            }
        }

        item { MiuixSectionHeader("主题色") }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    MiuixColorDots(settings.keyColor) { settings.updateKeyColor(it) }
                }
            }
        }

        item { MiuixSectionHeader("导航栏") }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                SwitchPreference(
                    title = "浮动胶囊底栏",
                    summary = "导航栏变为悬浮胶囊样式",
                    checked = settings.floatingBar,
                    onCheckedChange = { settings.updateFloatingBar(it) },
                )
            }
        }

        item { MiuixSectionHeader("主页文案") }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    SettingsTitle("未授权时的标题（默认：未获取超级用户权限）")
                    Spacer(Modifier.height(8.dp))
                    MiuixTextField(rootTitle) { rootTitle = it }
                    Row(modifier = Modifier.padding(top = 10.dp)) {
                        TextButton(
                            text = "保存",
                            onClick = {
                                settings.updateRootMissingTitle(rootTitle)
                                android.widget.Toast.makeText(context, "已保存", android.widget.Toast.LENGTH_SHORT).show()
                            },
                        )
                        Spacer(Modifier.width(8.dp))
                        TextButton(
                            text = "恢复默认",
                            onClick = {
                                settings.resetHomeTexts()
                                rootTitle = Settings.DEFAULT_ROOT_MISSING
                            },
                        )
                    }
                }
            }
        }

        item { MiuixSectionHeader("关于") }
        item { AboutCard() }
    }
}

@Composable
private fun MiuixTextField(value: String, onChange: (String) -> Unit) {
    BasicTextField(
        value = value,
        onValueChange = onChange,
        textStyle = TextStyle(color = colorScheme.onSurface, fontSize = 14.sp),
        cursorBrush = SolidColor(colorScheme.primary),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 58.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(colorScheme.surfaceContainer)
            .padding(12.dp),
    )
}

@Composable
private fun MiuixSearchField(value: String, onValueChange: (String) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(colorScheme.surfaceContainer)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        if (value.isEmpty()) {
            Text(
                text = "搜索分区名称或设备路径",
                fontSize = 14.sp,
                color = colorScheme.onSurfaceVariantSummary,
            )
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(color = colorScheme.onSurface, fontSize = 14.sp),
            cursorBrush = SolidColor(colorScheme.primary),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun MiuixSectionHeader(text: String) {
    Text(
        text = text,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        color = colorScheme.onSurfaceVariantSummary,
        modifier = Modifier.padding(start = 10.dp, top = 4.dp),
    )
}

@Composable
private fun SettingsTitle(text: String) {
    Text(text = text, fontSize = 13.sp, color = colorScheme.onSurfaceVariantSummary)
}

@Composable
private fun MiuixChoiceRow(options: List<Pair<String, Boolean>>, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { index, option ->
            Text(
                text = option.first,
                fontSize = 14.sp,
                color = if (option.second) Color.White else colorScheme.onSurface,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (option.second) colorScheme.primary else colorScheme.surfaceContainer)
                    .clickable { onSelect(index) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
private fun MiuixColorDots(selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        KEY_COLORS.forEach { value ->
            val isSelected = value == selected
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(value))
                    .then(
                        if (isSelected) Modifier.border(3.dp, colorScheme.onSurface, CircleShape)
                        else Modifier.border(1.dp, colorScheme.onSurface.copy(alpha = 0.15f), CircleShape)
                    )
                    .clickable { onPick(value) }
            )
        }
    }
}
