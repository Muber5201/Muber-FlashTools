package com.muber.flashtools

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class UiStyle { MIUIX, MATERIAL }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

val KEY_COLORS = listOf(
    0xFF2F6BFF, 0xFF36D167, 0xFF9C4DFF, 0xFFFF9F0A, 0xFFF72727, 0xFF00BCD4,
).map { it.toInt() }

class Settings private constructor(private val prefs: SharedPreferences) {

    var uiStyle by mutableStateOf(
        if (prefs.getString(KEY_UI_STYLE, "miuix") == "material") UiStyle.MATERIAL else UiStyle.MIUIX
    )
        private set

    var themeMode by mutableStateOf(
        when (prefs.getString(KEY_THEME_MODE, "system")) {
            "light" -> ThemeMode.LIGHT
            "dark" -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
    )
        private set

    var keyColor by mutableIntStateOf(prefs.getInt(KEY_KEY_COLOR, KEY_COLORS[0]))
        private set

    var floatingBar by mutableStateOf(prefs.getBoolean(KEY_FLOATING_BAR, true))
        private set

    var rootMissingTitle by mutableStateOf(prefs.getString(KEY_ROOT_MISSING, null) ?: DEFAULT_ROOT_MISSING)
        private set

    fun updateUiStyle(value: UiStyle) {
        uiStyle = value
        prefs.edit().putString(KEY_UI_STYLE, if (value == UiStyle.MATERIAL) "material" else "miuix").apply()
    }

    fun updateThemeMode(value: ThemeMode) {
        themeMode = value
        prefs.edit().putString(
            KEY_THEME_MODE,
            when (value) {
                ThemeMode.LIGHT -> "light"
                ThemeMode.DARK -> "dark"
                ThemeMode.SYSTEM -> "system"
            },
        ).apply()
    }

    fun updateKeyColor(value: Int) {
        keyColor = value
        prefs.edit().putInt(KEY_KEY_COLOR, value).apply()
    }

    fun updateFloatingBar(value: Boolean) {
        floatingBar = value
        prefs.edit().putBoolean(KEY_FLOATING_BAR, value).apply()
    }

    fun updateRootMissingTitle(value: String) {
        rootMissingTitle = value.ifBlank { DEFAULT_ROOT_MISSING }
        prefs.edit().putString(KEY_ROOT_MISSING, rootMissingTitle).apply()
    }

    fun resetHomeTexts() {
        rootMissingTitle = DEFAULT_ROOT_MISSING
        prefs.edit().remove(KEY_ROOT_MISSING).apply()
    }

    companion object {
        const val DEFAULT_ROOT_MISSING = "未获取超级用户权限"

        private const val KEY_UI_STYLE = "ui_style"
        private const val KEY_THEME_MODE = "theme_mode"
        private const val KEY_KEY_COLOR = "key_color"
        private const val KEY_FLOATING_BAR = "floating_bar"
        private const val KEY_ROOT_MISSING = "root_missing_title"

        fun load(context: Context): Settings =
            Settings(context.getSharedPreferences("muber_settings", Context.MODE_PRIVATE))
    }
}
