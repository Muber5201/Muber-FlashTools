package com.muber.flashtools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.LinkedHashMap
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

data class Partition(val name: String, val dev: String, val size: Long)

private val df = DecimalFormat("0.##")

fun fmtSize(bytes: Long): String = when {
    bytes <= 0 -> "未知"
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${df.format(bytes / 1024.0)} KB"
    bytes < 1024L * 1024 * 1024 -> "${df.format(bytes / 1024.0 / 1024.0)} MB"
    else -> "${df.format(bytes / 1024.0 / 1024.0 / 1024.0)} GB"
}

fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())

fun nowText(): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

/** 持久 su 会话：整个应用只申请一次超级用户权限。 */
object RootShell {
    private const val CLOSED = "__MUBER_STREAM_CLOSED__"

    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private val queue = LinkedBlockingQueue<String>()
    private var seq = 0
    private var alive = false

    data class ExecResult(val code: Int, val output: String, val timeout: Boolean = false)

    @Synchronized
    fun isAlive(): Boolean = alive && process?.isAlive() == true

    @Synchronized
    fun open(): Boolean {
        if (isAlive()) return true
        teardownLocked()
        return try {
            val p = ProcessBuilder("su").redirectErrorStream(true).start()
            process = p
            writer = BufferedWriter(OutputStreamWriter(p.outputStream, "UTF-8"))
            Thread {
                try {
                    BufferedReader(InputStreamReader(p.inputStream, "UTF-8")).useLines { lines ->
                        lines.forEach { queue.offer(it) }
                    }
                } catch (_: Exception) {
                } finally {
                    queue.offer(CLOSED)
                }
            }.apply { isDaemon = true; name = "muber-root-reader" }.start()
            alive = true
            true
        } catch (e: Exception) {
            alive = false
            false
        }
    }

    @Synchronized
    fun exec(cmd: String, timeoutMs: Long = 30_000): ExecResult {
        if (!open()) return ExecResult(-1, "无法启动 su：设备可能没有安装 KernelSU / Magisk")
        queue.clear()
        val id = ++seq
        val marker = "__MUBER_END_${id}__"
        try {
            val w = writer ?: return ExecResult(-1, "su 会话不可用")
            w.write(cmd)
            w.write("\n")
            w.write("echo \"$marker\$?\"\n")
            w.flush()
        } catch (e: Exception) {
            teardownLocked()
            return ExecResult(-1, "写入 su 会话失败：${e.message}")
        }

        val sb = StringBuilder()
        val deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            val remain = deadline - System.currentTimeMillis()
            if (remain <= 0) {
                teardownLocked()
                return ExecResult(-1, sb.toString(), true)
            }
            val line = queue.poll(remain, TimeUnit.MILLISECONDS)
            if (line == null) {
                teardownLocked()
                return ExecResult(-1, sb.toString(), true)
            }
            if (line == CLOSED) {
                teardownLocked()
                return ExecResult(-1, sb.toString())
            }
            if (line.startsWith(marker)) {
                return ExecResult(line.removePrefix(marker).trim().toIntOrNull() ?: -1, sb.toString())
            }
            sb.append(line).append('\n')
        }
    }

    @Synchronized
    fun teardown() {
        teardownLocked()
    }

    private fun teardownLocked() {
        alive = false
        try {
            writer?.write("exit\n")
            writer?.flush()
        } catch (_: Exception) {
        }
        try {
            process?.destroy()
        } catch (_: Exception) {
        }
        writer = null
        process = null
        queue.clear()
    }
}

object Scripts {
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"
    private fun sh(raw: String) = raw.replace('§', '$')

    val listPartitions: String = sh(
        """
        list_dir() {
          d="§1"
          [ -d "§d" ] || return 0
          for f in "§d"/*; do
            [ -e "§f" ] || continue
            n="§{f##*/}"
            t="§(readlink -f "§f" 2>/dev/null)"
            [ -n "§t" ] || t="§f"
            b="§{t##*/}"
            s="§(blockdev --getsize64 "§t" 2>/dev/null)"
            if [ -z "§s" ]; then
              z="§(cat /sys/class/block/§b/size 2>/dev/null)"
              if [ -n "§z" ]; then s=§((z*512)); else s=0; fi
            fi
            echo "P|§n|§t|§s"
          done
        }
        list_dir /dev/block/by-name
        list_dir /dev/block/mapper
        """.trimIndent()
    )

    fun flash(img: String, dev: String, size: Long): String = sh(
        """
        BS=8388608
        IMG=${q(img)}
        DEV=${q(dev)}
        SIZE=$size
        off=0
        while [ "§off" -lt "§SIZE" ]; do
          ERR="§(dd if="§IMG" of="§DEV" bs=§BS skip=§((off/BS)) seek=§((off/BS)) count=1 conv=notrunc 2>&1 >/dev/null)"
          if [ §? -ne 0 ]; then
            echo "MUBER_E dd 写入失败: §ERR"
            exit 1
          fi
          off=§((off+BS))
          [ "§off" -gt "§SIZE" ] && off=§SIZE
          echo "MUBER_P §off"
        done
        echo "MUBER_I 同步块设备缓存"
        sync
        echo "MUBER_DONE"
        """.trimIndent()
    )

    fun backup(dev: String, out: String, size: Long): String = sh(
        """
        BS=8388608
        DEV=${q(dev)}
        OUT=${q(out)}
        SIZE=$size
        mkdir -p "§(dirname "§OUT")" 2>/dev/null
        off=0
        while [ "§off" -lt "§SIZE" ]; do
          ERR="§(dd if="§DEV" of="§OUT" bs=§BS skip=§((off/BS)) seek=§((off/BS)) count=1 conv=notrunc 2>&1 >/dev/null)"
          if [ §? -ne 0 ]; then
            echo "MUBER_E 备份失败: §ERR"
            exit 1
          fi
          off=§((off+BS))
          [ "§off" -gt "§SIZE" ] && off=§SIZE
          echo "MUBER_P §off"
        done
        sync
        chmod 644 "§OUT" 2>/dev/null
        echo "MUBER_I 备份完成: §OUT"
        echo "MUBER_DONE"
        """.trimIndent()
    )

    fun readback(dev: String, size: Long): String = sh(
        """
        DEV=${q(dev)}
        SIZE=$size
        H="§(head -c "§SIZE" "§DEV" | sha256sum | cut -d' ' -f1)"
        echo "MUBER_H §H"
        echo "MUBER_DONE"
        """.trimIndent()
    )
}

object Partitions {
    suspend fun load(): List<Partition> = withContext(Dispatchers.IO) {
        val r = RootShell.exec(Scripts.listPartitions, 30_000)
        if (r.timeout) throw IllegalStateException("读取分区超时，请确认已授予超级用户权限")
        val map = LinkedHashMap<String, Partition>()
        r.output.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("P|")) {
                val parts = line.split("|")
                if (parts.size >= 4) {
                    val name = parts[1]
                    val dev = parts[2]
                    val size = parts[3].toLongOrNull() ?: 0L
                    if (name.isNotEmpty() && dev.isNotEmpty() && !map.containsKey(name)) {
                        map[name] = Partition(name, dev, size)
                    }
                }
            }
        }
        if (map.isEmpty()) throw IllegalStateException(
            "未读取到分区\n" + r.output.trim().take(200)
        )
        map.values.sortedBy { it.name.lowercase() }
    }
}

class JobHandle {
    @Volatile var process: Process? = null
    @Volatile var cancelled: Boolean = false

    fun cancel() {
        cancelled = true
        try {
            process?.destroy()
        } catch (_: Exception) {
        }
    }
}

data class JobOutcome(val ok: Boolean, val message: String, val meta: String? = null)

suspend fun runScript(
    script: String,
    handle: JobHandle,
    onLog: (String) -> Unit = {},
    onProgress: (Long) -> Unit = {},
): JobOutcome = withContext(Dispatchers.IO) {
    var error: String? = null
    var meta: String? = null
    try {
        val p = ProcessBuilder("su", "-c", script).redirectErrorStream(true).start()
        handle.process = p
        p.inputStream.bufferedReader().useLines { lines ->
            lines.forEach { line ->
                when {
                    line.startsWith("MUBER_P ") ->
                        line.removePrefix("MUBER_P ").trim().toLongOrNull()?.let(onProgress)
                    line.startsWith("MUBER_H ") ->
                        meta = line.removePrefix("MUBER_H ").trim()
                    line.startsWith("MUBER_E ") ->
                        error = line.removePrefix("MUBER_E ").trim()
                    line.startsWith("MUBER_I ") ->
                        onLog(line.removePrefix("MUBER_I ").trim())
                    line.isNotBlank() -> onLog(line.trim())
                }
            }
        }
        val code = p.waitFor()
        val err = error
        when {
            handle.cancelled -> JobOutcome(false, "已取消")
            err != null -> JobOutcome(false, err)
            code != 0 -> JobOutcome(false, "命令返回错误码 $code")
            else -> JobOutcome(true, "完成", meta)
        }
    } catch (e: Exception) {
        JobOutcome(false, if (handle.cancelled) "已取消" else "执行失败：${e.message}")
    }
}
