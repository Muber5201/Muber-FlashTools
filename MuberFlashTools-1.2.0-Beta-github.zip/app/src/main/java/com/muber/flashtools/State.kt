package com.muber.flashtools

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class AppState {
    var rootChecked by mutableStateOf(false)
    var rootOk by mutableStateOf(false)
    var manager by mutableStateOf("检测中")

    var partitions by mutableStateOf<List<Partition>>(emptyList())
    var partitionsLoading by mutableStateOf(false)
    var partitionsError by mutableStateOf<String?>(null)

    var target by mutableStateOf<Partition?>(null)

    var imageUri by mutableStateOf<Uri?>(null)
    var imageName by mutableStateOf<String?>(null)
    var imageSize by mutableStateOf(0L)

    var optBackup by mutableStateOf(true)
    var optVerify by mutableStateOf(false)

    var busy by mutableStateOf(false)
    var stage by mutableStateOf("")
    var progress by mutableStateOf(0f)
    var detail by mutableStateOf("")
    var message by mutableStateOf<String?>(null)
    var ok by mutableStateOf(false)
    var handle: JobHandle? = null

    val logs = mutableStateListOf<String>()

    fun log(line: String) {
        logs.add("[${nowText()}] $line")
        while (logs.size > 300) logs.removeAt(0)
    }
}
