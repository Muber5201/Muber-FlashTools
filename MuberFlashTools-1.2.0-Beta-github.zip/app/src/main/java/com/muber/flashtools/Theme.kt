package com.muber.flashtools

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.ThemeColorSpec
import top.yukonga.miuix.kmp.theme.ThemeController
import top.yukonga.miuix.kmp.theme.ThemePaletteStyle

@Composable
fun isDarkTheme(settings: Settings): Boolean = when (settings.themeMode) {
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
}

@Composable
fun MuberTheme(settings: Settings, content: @Composable () -> Unit) {
    val dark = isDarkTheme(settings)
    when (settings.uiStyle) {
        UiStyle.MIUIX -> {
            val controller = remember(dark, settings.keyColor) {
                ThemeController(
                    if (dark) ColorSchemeMode.Dark else ColorSchemeMode.Light,
                    keyColor = Color(settings.keyColor),
                    isDark = dark,
                    paletteStyle = ThemePaletteStyle.TonalSpot,
                    colorSpec = ThemeColorSpec.Spec2025,
                )
            }
            MiuixTheme(controller = controller, content = content)
        }

        UiStyle.MATERIAL -> {
            val scheme = remember(dark, settings.keyColor) {
                val primary = Color(settings.keyColor)
                if (dark) {
                    darkColorScheme(primary = primary)
                } else {
                    lightColorScheme(primary = primary)
                }
            }
            MaterialTheme(colorScheme = scheme, content = content)
        }
    }
}
